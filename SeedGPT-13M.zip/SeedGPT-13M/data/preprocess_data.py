import os
import json
import zarr
import numpy
import tiktoken
import argparse
from tqdm import tqdm

    
def preprocess_stream_to_zarr(dataset_path:str,output_file:str):
    z = zarr.open(output_file,"w")
    
    token_store = z.create_dataset("tokenized_data",shape=(0,),
                                   compressor=zarr.Blosc(cname='zstd', clevel=5, shuffle=2),
                                   dtype="i4",chunks=100_000)
    offset_store = z.create_dataset("tokenized_offset",shape=(0,),
                                    compressor=zarr.Blosc(cname='zstd', clevel=5, shuffle=2),
                                    dtype="i8",chunks=100_100)
    total_tokens = 0
    total_offest = [0]
    
    for file in os.listdir(dataset_path):
        if file.endswith(".jsonl"):
            filepath = os.path.join(dataset_path,file)
            print(f"Extracting from file -- {filepath}\n")
            with open(filepath,"r",encoding="utf-8") as f:
                for line in f:
                    data = json.loads(line)
                    txt = data["content"] + "<|endoftext|>"
                    encoded_txt = tokenizer.encode(txt,
                                                   allowed_special={"<|endoftext|>"})
                    encoded_txt = numpy.array(encoded_txt,dtype=numpy.int32)
                    ## Store in token_store
                    token_store.append(encoded_txt)
                    total_tokens += len(encoded_txt)
                    total_offest.append(total_tokens)
    offset_store[:] = numpy.array(total_offest,dtype=numpy.int64)
    print(f"Saved {len(token_store)} tokens to Zarr store {output_file}")
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser("Save the tokenized dataset")
    parser.add_argument("--input_dir",type=str,default="./",
                    help="Directory containing input *.jsonl files ")
    parser.add_argument("--output_file",default="./encoded_token.zarr",type=str,
                    help="Path to the output zarr file")
    arg = parser.parse_args()
    
    tokenizer = tiktoken.get_encoding("r50k_base")
    preprocess_stream_to_zarr(arg.input_dir,arg.output_file)
                      