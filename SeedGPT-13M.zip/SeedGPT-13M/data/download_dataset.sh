#!/bin/bash

sudo apt install -y git git-lfs

git lfs install

git clone https://www.modelscope.cn/datasets/OmniData/Pile-OpenWebText2.git

git clone https://www.modelscope.cn/datasets/OmniData/Pile-BookCorpus2.git


